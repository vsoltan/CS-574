--with train_corrmask=0:
    distance_threshold=0.01, epoch=99, hold_out_val_acc=0.56692821, test_acc=0.54679579
    distance_threshold=0.02, epoch=96, hold_out_val_acc=0.92137212, test_acc=0.88360316
    distance_threshold=0.04, epoch=53, hold_out_val_acc=0.99902356, test_acc=0.99789572

--with train_corrmask=1:
    epoch=94, hold_out_val_acc=0.84266418, test_acc=0.79433936
    rotation=[ 0.08437824 -0.21089926 -8.82652193]